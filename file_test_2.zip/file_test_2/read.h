int read()
{
   int num;
   FILE *fptr;
   if ((fptr = fopen("example.txt","r")) == NULL){
       printf("Error! opening file");
       // Program exits if the file pointer returns NULL.
       exit(1);
   }
   fscanf(fptr,"%d", &num);
   printf("Value of n=%d", num);
   fclose(fptr);
    printf("\nValue of n=%d", read());
   return num;
}
