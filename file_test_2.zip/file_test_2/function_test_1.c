#include "file.h"

int main()
{
    #ifdef m_menu_
    m_menu();
    #else
    printf("Main Menu disabled");
    #endif
    return 0;
}

