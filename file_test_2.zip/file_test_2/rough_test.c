
#include<stdio.h>
//#include<conio.h>
int main()
{
	//clrscr();
	int sml=1, i, limit;
	printf("How many smiley face you want to print ? ");
	scanf("%d",&limit);
	for(i=0; i<limit; i++)
	{
		printf("%c ",sml);
	}
	return 0;
}
