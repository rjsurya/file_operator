#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include "def_fun.h"

void dir_list(void);
void m_menu();
void write_txt(int);
int read_data();
int remove_file(char*);
void to_create_txt(char*);
int file_list_menu();

void m_menu()
{
    char *opt[10];
    printf("****************************************\n___Welcome the file handler using C!___\n****************************************\n");
    printf("\n1. Press 1 for view the options\n2. Press 2 for Entering data \n3. Press for Dir of this folder\n4. Files Handling\n");
    printf("****************************************\n");
    scanf("%s",opt);
    printf("%s",&opt);
    if(strcmp(opt,"help")==0)
    {
        printf("\nhelp printed");
    }
    else if(strcmp(opt,"3")==0)
    {
        dir_list();
    }
    else if(strcmp(opt,"4")==0)
    {
        file_list_menu();
    }
}

int file_list_menu()
{
    event1: ;
    int opt_num1;
    printf("\n****************************************\n");
    printf("1. To Create New File");
    printf("\n2. Over Right File");
    printf("\n3. To Append Data");
    printf("\n4. Write to Particular File");
    printf("\n5. Create JSON Format Files");
    printf("\n6. JSON Data Packet Format");
    printf("\n7. Delete Files");
    printf("\n8. Dir View");
    printf("\n9. CSV File Handling");
    printf("\n****************************************\n");
    printf("Enter the Option Number: ");
    scanf("%d",&opt_num1);
    printf("\n****************************************\n");
    char *file_name[10];
    char *text[10];
    switch (opt_num1){
    case 1:
        printf("\n****************************************\n");
        printf("Enter the File Name with Extension: ");
        scanf("%s",&file_name);
        printf("\n****************************************\n");
        to_create_txt(file_name);
        break;

    case 2:
        printf("\n****************************************\n");
        printf("Enter the Text to Insert");
        scanf("%s",&file_name);
        write_txt(file_name);
        printf("\n****************************************\n");
        break;

    case 3:
        printf("\n****************************************\n");
        printf("Enter the Text to Insert");
        scanf("%s",&file_name);
        append_txt(file_name);
        printf("\n****************************************\n");
        break;

    case 4:
        break;

    case 5:
        break;

    case 6:
        break;

    case 7:
        break;

    case 8:
        break;

    default:
        printf("\n****************************************\n");
        printf("Please Enter the Number Less then 8! :(");
        goto event1;
        printf("\n****************************************\n");
        return 0;
    }
}

void write_txt(char *num)
{
     FILE *fptr;
   if ((fptr = fopen("example.txt","w")) == NULL){
       printf("Error! opening file");
       // Program exits if the file pointer returns NULL.
       exit(1);
   }
   if(fptr == NULL)
   {
      printf("Error!");
      exit(1);
   }

   fprintf(fptr,"%s",num);
   fclose(fptr);
}

void append_txt(char *num)
{
     FILE *fptr;
   if ((fptr = fopen("example.txt","a")) == NULL){
       printf("Error! opening file");
       // Program exits if the file pointer returns NULL.
       exit(1);
   }
   if(fptr == NULL)
   {
      printf("Error!");
      exit(1);
   }

   fprintf(fptr,"%s",num);
   fclose(fptr);
}

int read_data()
{
   int num;
   FILE *fptr;
   if ((fptr = fopen("example.txt","r")) == NULL){
       printf("Error! opening file");
       // Program exits if the file pointer returns NULL.
       exit(1);
   }
   fscanf(fptr,"%d", &num);
  // printf("Value of n=%d", num);
   fclose(fptr);

   return num;
}

int remove_file(char *file_name)
{
   if (remove(file_name) == 0)
      printf("Deleted successfully");
   else
      printf("Unable to delete the file");

   return 0;
}

void to_create_txt(char *file_name)
{

   FILE *fptr;
    char a;
   if ((fptr = fopen(file_name,"w")) == NULL){
       printf("Error! opening file");
       // Program exits if the file pointer returns NULL.
       exit(1);
   }
   if(fptr == NULL)
   {
      printf("Error!");
      exit(1);
   }
}

void dir_list(void)
{
    struct dirent *de;  // Pointer for directory entry

    // opendir() returns a pointer of DIR type.
    DIR *dr = opendir(".");

    if (dr == NULL)  // opendir returns NULL if couldn't open directory
    {
        printf("Could not open current directory" );
        //return 0;
    }

    // Refer http://pubs.opengroup.org/onlinepubs/7990989775/xsh/readdir.html
    // for readdir()
    while ((de = readdir(dr)) != NULL)
            printf("%s\n", de->d_name);

    closedir(dr);
}
