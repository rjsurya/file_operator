#include "file.h"
int main()
{
    char *filename[10];
    int num,a;
    remove_file("example34.txt");
    dir_list();
    printf("Enter new file name with file type: ");
    scanf("%s",filename);
    printf("Enter num: ");
    scanf("%d",&num);
    to_create_txt(*filename);
    write_txt(num);
    a=read_data();
    printf("\nValue from txt: %d",a);
    return 0;
}

