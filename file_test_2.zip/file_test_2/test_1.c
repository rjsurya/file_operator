#include <stdio.h>
#include <stdlib.h>
int main_1()
{
   int num;
   FILE *fptr;
   if ((fptr = fopen("file.txt","a")) == NULL){
       printf("Error! opening file");
       // Program exits if the file pointer returns NULL.
       exit(1);
   }
   if(fptr == NULL)
   {
      printf("Error!");
      exit(1);
   }
   printf("Enter num: ");
   scanf("%d",&num);
   fprintf(fptr,"%d",num);
   fclose(fptr);
   return 0;

   return 0;
}

